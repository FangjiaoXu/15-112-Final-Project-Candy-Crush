# -*- coding: utf-8 -*-
import pygame
import time
import gamegame2 as gamegame

imagep="0.png"
imagered="1.png"
imageyellow="2.png"
imageorange="3.png"
imagegreen="4.png"
imageblue="5.png"
imagepurple="6.png"
background="brown.png"
button2="bt2.png"
button="bt3.png"

class firstscreen:
    def __init__(self):
        #set the begin screen
        pygame.init()
        self.screen = pygame.display.set_mode((700, 500))
        screen=self.screen
        back=pygame.image.load(background).convert_alpha()
        screen.blit(back,(0,0))
        bt=pygame.image.load(button2).convert_alpha()
        screen.blit(bt,(500,100))
        screen.blit(bt,(500,300))
        font=pygame.font.Font("stasia.ttf",40)
        font.set_bold(True)
        font1=pygame.font.Font("stasia.ttf",150)
        font2=pygame.font.Font("stasia.ttf",40)
        fx=font2.render("fx",True,(255,255,255))
        screen.blit(fx,(650,450))
        begin=font.render("BEGIN",True,(255,255,255))
        screen.blit(begin,(520,125))
        intro=font.render("HELP",True,(255,255,255))
        screen.blit(intro,(525,325))
        em=font1.render("Emoji",True,(255,255,255))
        screen.blit(em,(100,100))
        cr=font1.render("Crush",True,(255,255,255))
        screen.blit(cr,(150,200))
        pygame.display.set_caption('Emoji Crush')
        pygame.display.flip()
        running=1
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                        running=0
                if event.type==pygame.MOUSEBUTTONUP:
                    pos=pygame.mouse.get_pos()
                    #begin the game
                    if pos[0]>500 and pos[0]<650 and pos[1]>100 and pos[1]<200:
                        #call game board
                        gameboard()
                        running=0
                    #introduction to the game
                    if pos[0]>500 and pos[0]<650 and pos[1]>300 and pos[1]<400:
                        screen.blit(back,(0,0))
                        screen.blit(bt,(500,100))
                        screen.blit(bt,(500,300))
                        font3=pygame.font.Font("stasia.ttf",30)
                        font3.set_bold(True)
                        fx=font2.render("fx",True,(255,255,255))
                        screen.blit(fx,(650,450))
                        begin=font.render("BEGIN",True,(255,255,255))
                        screen.blit(begin,(520,125))
                        intro=font.render("HELP",True,(255,255,255))
                        screen.blit(intro,(525,325))
                        eg=font.render("How to play this game?",True,(255,255,255))
                        screen.blit(eg,(50,50))
                        intro1=font3.render("This is a game like Candy",True,(255,255,255))
                        screen.blit(intro1,(50,100))
                        intro2=font3.render("Crush. You need to swap two",True,(255,255,255))
                        screen.blit(intro2,(50,150))
                        intro3=font3.render("neighbor emoji to make a match.",True,(255,255,255))
                        screen.blit(intro3,(50,200))
                        intro4=font3.render("You will earn 10 pointd for",True,(255,255,255))
                        screen.blit(intro4,(50,250))
                        intro5=font3.render("each matched emoji. You will",True,(255,255,255))
                        screen.blit(intro5,(50,300))
                        intro6=font3.render("be given 120 seconds to",True,(255,255,255))
                        screen.blit(intro6,(50,350))
                        intro7=font3.render("play the game.",True,(255,255,255))
                        screen.blit(intro7,(50,400))
                        pygame.display.update()
        
class gameboard:
    def __init__(self): 
        pygame.init()
        pygame.mixer.init()
        self.score=0
        self.screen = pygame.display.set_mode((700, 500))
        self.game=gamegame.game()
        screen=self.screen
        white=[255, 255, 255]
        black=[0,0,0]
        #screen.fill(white)
        back=pygame.image.load(background).convert_alpha()
        screen.blit(back,(0,0))
        self.getbutton()
        pygame.display.set_caption('Emoji Crush')
        self.images={1:pygame.image.load(imagered).convert_alpha(),
        2:pygame.image.load(imageyellow).convert_alpha(),
        3:pygame.image.load(imageorange).convert_alpha(),
        4:pygame.image.load(imagegreen).convert_alpha(),
        5:pygame.image.load(imageblue).convert_alpha(),
        6:pygame.image.load(imagepurple).convert_alpha(),
        0:pygame.image.load(imagep).convert_alpha()}
        self.drawlines()
        self.getboard()
        pygame.display.flip()
        poslist=[]
        time=pygame.time.get_ticks()
        seconds=(pygame.time.get_ticks()-time)/1000
        pre=0
        running = 1
        #set music
        pygame.mixer.music.load("bgm.wav")
        pygame.mixer.music.set_volume(0.5)
        pygame.mixer.music.play(-1)
        #song=pygame.mixer.Sound("bgm.wav")
        #sound=pygame.mixer.Sound("blip.wav")
        #song.set_volume(0.5)
        #sound.set_volume(1)
        #song.play(-1)
        while running:
        #while seconds<120 and running:
            seconds=(pygame.time.get_ticks()-time)/1000
            if seconds!=pre:
                #show time
                bt=self.bt
                font=pygame.font.Font("stasia.ttf",20)
                font1=pygame.font.Font("stasia.ttf",40)
                screen.blit(bt,(500,75))
                font.set_bold(True)
                timet=font.render("TIME",True,(255,255,255))
                screen.blit(timet,(550,75))
                font1=pygame.font.Font("stasia.ttf",40)
                realtime=font1.render(str(120-seconds)+"s",True,(255,255,255))
                screen.blit(realtime,(550,95))
                pre=seconds
                pygame.display.update()
            #change it to 120／5／10
            #if time is up, stop the game
            if seconds>120:
                #closeit(self.score)
                running=0
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                        running=0
                if event.type==pygame.MOUSEBUTTONUP:
                    pos=pygame.mouse.get_pos()
                    #position[0] is row num
                    #position[1] is col num
                    #get the position and index
                    position=self.getindex(pos[0],pos[1])
                    if position!=[]:
                        poslist.append(position[0])
                        poslist.append(position[1])
                    #if there are two index
                    if len(poslist)==4:
                        x1=poslist[0]
                        y1=poslist[1]
                        x2=poslist[2]
                        y2=poslist[3]
                        #if the two emoji are next to each other
                        if (x1==x2 and abs(y1-y2)==1) or (y1==y2 and abs(x1-x2)==1):
                            #change the position
                            self.game.changepos(poslist[0],poslist[1],poslist[2],poslist[3])
                            self.updateboard(poslist[0],poslist[1],poslist[2],poslist[3])
                            #check match
                            self.game.countmatch(poslist[0],poslist[1],poslist[2],poslist[3])
                            if self.game.count==0:
                                #no match, change back
                                self.game.changepos(poslist[0],poslist[1],poslist[2],poslist[3])
                                self.updateboard(poslist[0],poslist[1],poslist[2],poslist[3])
                            else:
                                #make move
                                self.game.makemove(poslist[0],poslist[1],poslist[2],poslist[3])
                                self.textupdate(self.game.count)
                                #sound.play()
                                self.getboard()
                                #get new emoji
                                self.game.drop()
                                self.getboard()
                        #print poslist
                        poslist=[]
        #song.stop()
        pygame.mixer.music.stop()
        closeit(self.score)
        #pygame.quit()
            
    def textupdate(self,con):
        #update the score
        screen=self.screen
        self.score=self.score+con*10
        screen.blit(self.bt,(500,210))
        screen.blit(self.bt,(500,345))
        font=pygame.font.Font("stasia.ttf",20)
        font.set_bold(True)
        scoret=font.render("SCORE",True,(255,255,255))
        screen.blit(scoret,(550,210))
        last=font.render("LAST MOVE",True,(255,255,255))
        screen.blit(last,(530,345))
        font1=pygame.font.Font("stasia.ttf",40)
        lastt=font1.render(str(con*10),True,(255,255,255))
        screen.blit(lastt,(550,365))
        totalt=font1.render(str(self.score),True,(255,255,255))
        screen.blit(totalt,(550,230))
        
    def getbutton(self):
        #set the shown screen
        screen=self.screen
        bt=pygame.image.load(button).convert_alpha()
        self.bt=bt
        screen.blit(bt,(500,75))
        screen.blit(bt,(500,210))
        screen.blit(bt,(500,345))
        font=pygame.font.Font("stasia.ttf",20)
        font1=pygame.font.Font("stasia.ttf",40)
        font.set_bold(True)
        timet=font.render("TIME",True,(255,255,255))
        screen.blit(timet,(550,75))
        scoret=font.render("SCORE",True,(255,255,255))
        screen.blit(scoret,(550,210))
        zerot=font1.render("0",True,(255,255,255))
        screen.blit(zerot,(550,230))
        zeros=font1.render("120s",True,(255,255,255))
        screen.blit(zeros,(550,95))
        lastt=font.render("LAST MOVE",True,(255,255,255))
        screen.blit(lastt,(530,345))
        
    def updateboard(self,x1,y1,x2,y2):
        #update game board
        listnum=self.game.listnum
        screen=self.screen
        images=self.images
        ind1=listnum[x1][y1]
        pos1y=50*y1+51
        pos1x=50*x1+51
        screen.blit(images[ind1], (pos1y, pos1x))
        ind2=listnum[x2][y2]
        pos2y=50*y2+51
        pos2x=50*x2+51
        screen.blit(images[ind2], (pos2y, pos2x))
        pygame.display.update()
        
    def getindex(self,x,y):
        #get the index of current emoji
        for i in range(0,8):
            for j in range(0,8):
                #ind=listnum[i][j]
                left=50*j+51
                up=50*i+51
                right=left+50
                down=up+50
                if left<x and right>x and up<y and down>y:
                    return [i,j]
        return []

    def getboard(self):
        #get the init game board
        listnum=self.game.listnum
        screen=self.screen
        images=self.images
        '''for i in listnum:
            print i'''
        for i in range(0,8):
            for j in range(0,8):
                ind=listnum[i][j]
                #x is row, y is col
                y=50*j+51
                x=50*i+51
                if ind in [0,1,2,3,4,5,6]:
                    screen.blit(images[ind], (y, x))
                
        pygame.display.update()
        pygame.time.wait(200)

    def drawlines(self):
        #draw lines and grids
        screen=self.screen
        black=[0,0,0]
        pygame.draw.line(screen,black,[49,49],[451,49],2)
        pygame.draw.line(screen,black,[50,100],[450,100],1)
        pygame.draw.line(screen,black,[50,150],[450,150],1)
        pygame.draw.line(screen,black,[50,200],[450,200],1)
        pygame.draw.line(screen,black,[50,250],[450,250],1)
        pygame.draw.line(screen,black,[50,300],[450,300],1)
        pygame.draw.line(screen,black,[50,350],[450,350],1)
        pygame.draw.line(screen,black,[50,400],[450,400],1)
        pygame.draw.line(screen,black,[49,450],[451,450],2)
        pygame.draw.line(screen,black,[49,49],[49,451],2)
        pygame.draw.line(screen,black,[100,50],[100,450],1)
        pygame.draw.line(screen,black,[150,50],[150,450],1)
        pygame.draw.line(screen,black,[200,50],[200,450],1)
        pygame.draw.line(screen,black,[250,50],[250,450],1)
        pygame.draw.line(screen,black,[300,50],[300,450],1)
        pygame.draw.line(screen,black,[350,50],[350,450],1)
        pygame.draw.line(screen,black,[400,50],[400,450],1)
        pygame.draw.line(screen,black,[451,49],[451,451],2)

class closeit:
    def __init__(self,score):
        #set the screen
        pygame.init()
        pygame.mixer.init()
        pygame.mixer.music.load("gameover1.wav")
        pygame.mixer.music.set_volume(0.5)
        pygame.mixer.music.play()
        self.score=score
        self.screen = pygame.display.set_mode((700, 500))
        screen=self.screen
        back=pygame.image.load(background).convert_alpha()
        screen.blit(back,(0,0))
        bt=pygame.image.load(button2).convert_alpha()
        screen.blit(bt,(75,350))
        screen.blit(bt,(275,350))
        screen.blit(bt,(475,350))
        font=pygame.font.Font("stasia.ttf",40)
        font.set_bold(True)
        font1=pygame.font.Font("stasia.ttf",80)
        font1.set_bold(True)
        font2=pygame.font.Font("stasia.ttf",50)
        font2.set_bold(True)
        gameover=font1.render("GAME OVER",True,(255,255,255))
        screen.blit(gameover,(170,50))
        showscore=font2.render("Your score is: "+str(score),True,(255,255,255))
        screen.blit(showscore,(130,180))
        home=font.render("Home",True,(255,255,255))
        screen.blit(home,(95,375))
        play=font.render("Play",True,(255,255,255))
        screen.blit(play,(295,375))
        qu=font.render("Quit",True,(255,255,255))
        screen.blit(qu,(495,375))
        pygame.display.set_caption('Emoji Crush')
        f=open("highest.txt","r")
        high=int(f.readline())
        f.close()
        if high<score:
            high=score
            f=open("highest.txt","w")
            f.write(str(high))
            f.close()
        showhigh=font2.render("Highest score is: "+str(high),True,(255,255,255))
        screen.blit(showhigh,(75,220))
        pygame.display.flip()
        running=1
        time=pygame.time.get_ticks()
        seconds=(pygame.time.get_ticks()-time)/100
        while running:
            seconds=(pygame.time.get_ticks()-time)/100
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                        running=0
                if event.type==pygame.MOUSEBUTTONUP:
                    pos=pygame.mouse.get_pos()
                    #go back to home
                    if pos[0]>95 and pos[0]<245 and pos[1]>375 and pos[1]<475:
                        firstscreen()
                        running=0
                    #play again
                    elif pos[0]>295 and pos[0]<445 and pos[1]>375 and pos[1]<475:
                        gameboard()
                        running=0
                    #exit
                    elif pos[0]>495 and pos[0]<645 and pos[1]>375 and pos[1]<475:
                        running=0
        pygame.quit()
        
firstscreen()

